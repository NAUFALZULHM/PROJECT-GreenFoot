import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HeroUpgrade here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HeroUpgrade extends Actor
{
    int countT=0;
    int durasiHU=0;
    /**
     * Act - do whatever the HeroUpgrade wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        
    }
    public HeroUpgrade(){
        GreenfootImage HeroUp=getImage();
        HeroUp.scale(100,50);
        
        countT++;
        if (countT>20){
            shoot();
            countT=0;
        }
        durasiHU++;
        if (durasiHU==600){
            getWorld().removeObject(this);
        }
    }
    void shoot(){
        //abstraction method shoot() untuk hero menembak peluru
        //keluar peluru
        Ammo ammo = new Ammo();
        getWorld().addObject( ammo,getX(),getY());
        Greenfoot.playSound("ammo.wav");
    }
}
