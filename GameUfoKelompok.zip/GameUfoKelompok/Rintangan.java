import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pipa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rintangan extends Actor
{
    /**
     * Act - do whatever the Pipa wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Rintangan(){
        //Mengatur ukuran gambar pipa
        GreenfootImage Image = getImage();
        Image.scale(300, 700);
    }
    public void act()
    {
        setLocation(getX() -1, getY());
        if(getX() <= 1 ){
            setLocation(getX() +600, Greenfoot.getRandomNumber(250)+50);
        }
    }
}
