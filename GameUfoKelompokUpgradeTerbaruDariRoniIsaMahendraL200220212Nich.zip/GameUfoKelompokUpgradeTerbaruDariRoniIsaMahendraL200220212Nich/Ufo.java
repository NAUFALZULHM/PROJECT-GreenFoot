import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ufo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ufo extends Actor
{
    //membuat variabel dan memberi nilai pada variabel tersebut
    private double g = -1;//sebagai kolaborasi dengan y (nilai awal untuk gerakan/gravitasi pada Flappybird
    private double y = 200; //Flappybird akan mulai pada koordinat y=200
    private boolean haspressed = false;//telah ditekan
    private boolean isalive = true;//hidup
    private boolean isacross = false;//ada di seberang
    private boolean hasaddscore = false;//memiliki nilai tambah
    int count=0;
    int H=0;
    /**
     * Act - do whatever the Flappybird wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Ufo(){
        //Mengatur ukuran gambar dari Flappybird
        GreenfootImage Image = getImage();
        Image.scale(50, 40);
    }
    public void act()
    {
        count++;
        if (count>20){
            shoot();
            count=0;
        }
        // Jika tekan spasi, koordinat y akan bertambah dan turun ke bawah
        if(spacePressed()){
            g = 2;//jika di tekan spasi Flappybird akan bergerak sejauh 2(atau ke bawah)
        }
        g += -0.1;//Nilai g meningkat -0.1 setiap saat(jika Flappybird di diamkan maka g akan selalu bertambah dan Flappybird semakin cepat naik
        y += g;//Nilai y tidak berubah dengan kecepatan konstan (kecepatan Flappybird tidak akan berubah)
        setLocation(getX(), (int)(y));
        
        //Jika menabrak rintangan maka Flappybird akan mati
        if(isTouchRintangan()){
            isalive = false;
        }
        //pemberian suara saat game over
        if(isTouchRintangan()){
            isalive = false;
        }
        //setelah menyentuh musuh mati
        if(isTouching(Musuh.class)){
            isalive=false;
            Greenfoot.playSound("peng.mp3");
            
        }
        if(isTouching(TriggerUpgrade.class)){
            MyWorld.ngerespawnTU.add(1);
           getWorld().addObject(new HeroUpgrade(),getX(),(int)(y));
           getImage().setTransparency(0);
           H++;
           if (H==100){
                getImage().setTransparency(255);
        }
            
            
        }
        
        
        //setelah jatuh atau menabrak rintangan maka Flappybird hilang(mati)
        if(!isalive){
            getWorld().addObject(new Gameover(), 300, 200);
            getWorld().removeObject(this);
        }
        //penambahan skor setelah melewati rintangan dan pemberian sound effect
        if(!hasaddscore && isacross && isalive){
            Greenfoot.playSound("score.mp3");
            Score.add(1);
        }
        hasaddscore = isacross;
        
    }
    void shoot(){
        //abstraction method shoot() untuk hero menembak peluru
        //keluar peluru
        Ammo ammo = new Ammo();
        getWorld().addObject( ammo,getX(),getY());
        Greenfoot.playSound("ammo.wav");
    }
    public boolean spacePressed(){
        boolean pressed = false;
        if(Greenfoot.isKeyDown("Space")){
            if(!haspressed){//Memberi sound effect
                Greenfoot.playSound("flay.mp3");
                pressed = true;
            }
            haspressed = true;
        }else{
            haspressed = false;
        }
        return pressed;
    }
    //pemberian sound effect ketika menabrak pipa dan jatuh
    public boolean isTouchRintangan(){
        isacross = false;
        for(Rintangan rintangan : getWorld().getObjects(Rintangan.class)){
            if(Math.abs(rintangan.getX() - getX()) < 69){
            if(Math.abs(rintangan.getY() + 30 - getY()) > 69){
                Greenfoot.playSound("peng.mp3");
                isalive = false;
            }
            isacross = true;
        }
    }
    return !isalive;
}
}
