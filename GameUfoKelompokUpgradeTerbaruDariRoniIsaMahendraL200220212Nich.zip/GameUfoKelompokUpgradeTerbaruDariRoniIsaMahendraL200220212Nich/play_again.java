import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class play_again here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class play_again extends Actor
{
    /**
     * Act - do whatever the play_again wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public play_again() 
    {
        // Add your action code here.
        GreenfootImage image = getImage();
        image.scale(50, 40);
    }    
    public void play_again()
    {
    if(Greenfoot.mousePressed(this))
    {
        getImage().scale((int)Math.round(getImage().getWidth()*1),
        (int)Math.round(getImage().getHeight()*1));
    }    
    if(Greenfoot.mouseClicked(this))
    {
        Greenfoot.delay(5);
        Greenfoot.setWorld(new MyWorld());  
    }   
  }
  public void act()
 {
     play_again();
    }
}




