import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Musuh here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
 
public class Musuh extends Actor
{
    /**
     * Act - do whatever the Musuh wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //respawn sesuatu agar tidak terlalu di pinggir layar (memberi batas respawn)
    public int batasRespawn(int start, int end){
        int normal=Greenfoot.getRandomNumber(end-start);
        return normal+start;
    }
    public Musuh(){//mengatur ukuran/scale musuh 
        GreenfootImage Musuh = getImage();
        Musuh.scale(50,50);
    }
    public void act()
    {
        //mengatur kecepatan dan respawn setelah melewati koordinat x <= 10
        setLocation (getX()-4, getY());
        if (getX()<=10){
            setLocation(599,batasRespawn(100,320));
        }
        //jika terkena peluru
        //skor nambah 1
        //lalu meledak
        if(isTouching(Ammo.class)){
            Score.add(1);
            removeTouching(Ammo.class);
            Meledak();
        }
    }
    void Meledak(){
        //menambah object blast
        //musuh muncul
        getWorld().addObject(new Blast(), getX(), getY());
        getWorld().addObject(new Musuh(),599,batasRespawn(100,320));
        //memutar sound blast
        //musuh hilang
        Greenfoot.playSound("explosion90an.wav");
        getWorld().removeObject(this);
    }
}
