import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pipa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rintangan extends Actor
{
    /**
     * Act - do whatever the Pipa wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Rintangan(){
        //Mengatur ukuran gambar rintangan
        GreenfootImage Image = getImage();
        Image.scale(380,800);
    }
    public void act()
    {
        // Membuat rintangan memiliki ukuruan panjang atas/bawah yang acak
        setLocation(getX() -1, getY());
        if(getX() <= 1 ){
            setLocation(getX() +600, Greenfoot.getRandomNumber(250)+50);
        }
    }
}
