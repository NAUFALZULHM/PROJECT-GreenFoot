import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class play_again here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class play_again extends Actor
{
    /**
     * Act - do whatever the play_again wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public play_again() 
    {
        // Menentukan ukuran Tombol untuk replay game
        GreenfootImage image = getImage();
        image.scale(50, 40);
    }    
    public void play_again()
    {//jika di tekan, object play again akan sedikit membesar 1.5 agar terkesan seperti animasi ditekan
        if(Greenfoot.mousePressed(this))
        {
            getImage().scale((int)Math.round(getImage().getWidth()*1.5),
            (int)Math.round(getImage().getHeight()*1.5));
        }    
        // Mereplay game saat tombol ditekan
        if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.delay(5);
            Greenfoot.setWorld(new MyWorld());  
        }   
     }
      public void act()
    { //memulai game lagi
         play_again();
    }
}




