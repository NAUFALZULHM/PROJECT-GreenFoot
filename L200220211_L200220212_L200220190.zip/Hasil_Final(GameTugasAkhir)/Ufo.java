import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ufo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ufo extends Actor
{
    //membuat variabel dan memberi nilai pada variabel tersebut
    //doble = float di python
    private double g = -1;//sebagai kolaborasi dengan y (nilai awal untuk gerakan/gravitasi pada Ufo
    private double y = 200; //Ufo akan mulai pada koordinat y=200
    private boolean haspressed = false;//telah ditekan
    private boolean isalive = true;//hidup
    private boolean isacross = false;//ada di seberang
    private boolean hasaddscore = false;//memiliki nilai tambah
    int count=0;
    
    /**
     * Act - do whatever the Flappybird wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Ufo(){
        //Mengatur ukuran gambar dari Flappybird
        GreenfootImage Image = getImage();
        Image.scale(50, 40);
    }
    public void act()
    {
        //untuk (Ufo) agar dapat menembak otomatis
        count++;
        if (count>20){
            shoot();
            count=0;
        }
        // Jika tekan spasi, koordinat y akan bertambah dan turun ke bawah
        if(spacePressed()){
            g = 2;//jika di tekan spasi Ufo akan bergerak sejauh 2(atau ke bawah)
        }
        g += -0.1;//Nilai g meningkat -0.1 setiap saat(jika Ufo di diamkan maka g akan selalu bertambah dan Ufo semakin cepat naik
        y += g;//Nilai y tidak berubah dengan kecepatan konstan (kecepatan Ufo tidak berubah)
        setLocation(getX(), (int)(y));
        //Jika menabrak rintangan maka Ufo akan mati/kalah
        if(isTouchRintangan()){
            isalive = false;
        }
        //setelah menyentuh musuh mati
        if(isTouching(Musuh.class)){
            isalive=false;
            Greenfoot.playSound("peng.mp3");
        }
        //setelah jatuh atau menabrak rintangan maka Ufo hilang(mati)
        if(!isalive){
            getWorld().addObject(new Gameover(), 300, 200);
            getWorld().removeObject(this);
        }
        //penambahan skor setelah melewati rintangan dan pemberian sound effect
        if(!hasaddscore && isacross && isalive){
            Greenfoot.playSound("score.mp3");
            Score.add(1);
        }
        hasaddscore = isacross;
    }
    void shoot(){
        //abstraction method shoot() untuk hero menembak peluru
        //keluar peluru
        //menambah sound effect
        Ammo ammo = new Ammo();
        getWorld().addObject( ammo,getX(),getY());
        Greenfoot.playSound("ammo.wav");
    }
    public boolean spacePressed(){
        boolean pressed = false;
        if(Greenfoot.isKeyDown("Space")){
            if(!haspressed){//Memberi sound effect
                Greenfoot.playSound("flay.mp3");
                pressed = true;
            }
            haspressed = true;
        }else{
            haspressed = false;
        }
        return pressed;
    }
    //pemberian sound effect ketika menabrak rintangan 
    public boolean isTouchRintangan(){
        isacross = false;
    for(Rintangan rintangan : getWorld().getObjects(Rintangan.class)){
        if(Math.abs(rintangan.getX() - getX()) < 100){
            if(Math.abs(rintangan.getY() + 30 - getY()) > 100){
                Greenfoot.playSound("peng.mp3");
                isalive = false;
            }
            isacross = true;
        }
    }
    return !isalive;
    }
}
