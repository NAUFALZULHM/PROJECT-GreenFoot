import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TriggerUpgrade here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TriggerUpgrade extends Actor
{
    /**
     * Act - do whatever the TriggerUpgrade wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int Trespawn=0;
    public int batasRespawn(int start, int end){
        int normal=Greenfoot.getRandomNumber(end-start);
        return normal+start;
    }
    public TriggerUpgrade(){
        GreenfootImage TU = getImage();
        TU.scale(100,50);
    }
    public void act()
    {
        // Add your action code here.
        // animasi bergerak ke kiri
        setLocation(getX()-2,getY());
        
        //mentrigger agar kembali ke bagian kanan, jadi seolah olah muncul terus
        if (isAtEdge()){
            getImage().setTransparency(0);
        }
        if(getImage().getTransparency()==0 && isAtEdge()){
            Trespawn++;
            if(Trespawn==60){
                setLocation(599,batasRespawn(40,360));
                getImage().setTransparency(255);
                Trespawn=0;
            }
        }
        if(MyWorld.ngerespawnTU.getValue()==1){
            setLocation(0,600);
            getImage().setTransparency(0);
            MyWorld.ngerespawnTU.add(-1);
            
        }
    
        }
    
}
