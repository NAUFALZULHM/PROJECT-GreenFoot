import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HeroUpgrade here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HeroUpgrade extends Actor
{
    int countT=0;
    int durasiHU=0;
    private double g = -1;//sebagai kolaborasi dengan y (nilai awal untuk gerakan/gravitasi pada Flappybird
    private double y = 200; //Flappybird akan mulai pada koordinat y=200
    private boolean haspressed = false;//telah ditekan
    private boolean isalive = true;//hidup
    private boolean isacross = false;//ada di seberang
    private boolean hasaddscore = false;//memiliki nilai tambah
    int count=0;
    /**
     * Act - do whatever the HeroUpgrade wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if(spacePressed()){
            g = 2;//jika di tekan spasi Flappybird akan bergerak sejauh 2(atau ke bawah)
        }
        g += -0.1;//Nilai g meningkat -0.1 setiap saat(jika Flappybird di diamkan maka g akan selalu bertambah dan Flappybird semakin cepat naik
        y += g;//Nilai y tidak berubah dengan kecepatan konstan (kecepatan Flappybird tidak akan berubah)
        setLocation(getX(), (int)(y));
        //Jika menabrak rintangan maka Flappybird akan mati
        countT++;
        getImage().setTransparency(255);
        if (countT>20){
            shoot();
            countT=0;
        }
        durasiHU++;
        if (durasiHU==100){
            getWorld().removeObject(this);
            
        }
    }
    public boolean spacePressed(){
        boolean pressed = false;
        if(Greenfoot.isKeyDown("Space")){
            if(!haspressed){//Memberi sound effect
                Greenfoot.playSound("flay.mp3");
                pressed = true;
            }
            haspressed = true;
        }else{
            haspressed = false;
        }
        return pressed;
        
    }
    public HeroUpgrade(){
        GreenfootImage HeroUp=getImage();
        HeroUp.scale(100,50);
        
        
    }
    void shoot(){
        //abstraction method shoot() untuk hero menembak peluru
        //keluar peluru
        Ammo ammo = new Ammo();
        getWorld().addObject( ammo,getX(),getY()+25);
        Ammo ammo2 = new Ammo();
        getWorld().addObject( ammo2,getX(),getY()-25);
        Greenfoot.playSound("ammo.wav");
    }
}
