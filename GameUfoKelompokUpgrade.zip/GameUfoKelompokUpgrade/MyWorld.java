import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    //static GreenfootSound bg = new GreenfootSound("bggame.wav");
    static Counter ngerespawnTU=new Counter("hp");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600,400, 1); 
        prepare();
        addObject(new Ufo(),100,200);
        //addObject(new Flappybird(),100,200);
        addObject(new Rintangan(),300, 150);
        addObject(new Rintangan(),600, 150);
        addObject(new Score(),300, 100);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        //setBackground("bggame.wav");
        play_again play_again = new play_again();
        addObject(play_again,4,19);
        play_again.setLocation(36,12);
        //for (int i =0;i<5; i++){
            //Musuh musuh = new Musuh();
            //addObject(musuh,Greenfoot.getRandomNumber(599),Greenfoot.getRandomNumber(350));
    //}
    ngerespawnTU.setValue(0);
    }   
    

    public void started(){
        //started in class greenfoot.World
        //menambahkan backsound dan menglooping soundnya
           GreenfootSound bg = new GreenfootSound("bggame.mp3");
           bg.playLoop();
    }
    
}
